[everett_police://<name>]
poll_seconds = <integer>
* Seconds between scans. Minimum 300. Default 3600.
lookback_days = <integer>
* Rolling incident window in days. Default 30. Set 0 for all history.
page_size = <integer>
* Rows per API page. Range 1–10000. Default 1000.
token_env = <string>
* Environment variable holding an optional Socrata application token.
* Default SOCRATA_APP_TOKEN. Never put the token itself in this setting.
